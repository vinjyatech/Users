﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using StoreUsers.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StoreUsers.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private ILogger _logger;

        public UserController(ILogger<UserController> logger)
        {
            _logger = logger;
        }

        [HttpGet("/api/getwomens")]
        public IEnumerable<UserModel> GetWomens(List<UserModel> userModels)
        {
            var results = userModels.Where(o => (o.Gender == Gender.Women) &&
                              (o.Age <25));

            return results;
        }

        [HttpGet("/api/youngestman")]
        public IEnumerable<UserModel> GetYoungestMan(List<UserModel> userModels)
        {
            int minAge = userModels.Min(s => s.Age);
            var results = userModels.Where(o => (o.Gender == Gender.Men) &&
                              (o.Age == minAge));

            return results;
        }

        [HttpGet("/api/getwomenrole")]
        public IEnumerable<UserModel> GetWomenRole(List<UserModel> userModels)
        {
            int minAge = userModels.Min(s => s.Age);
            var results = userModels.Where(o => (o.Gender == Gender.Women) &&
                              (o.Roles.Any(name =>
          name.Equals(Roles.Manger) && o.Roles.Contains(Roles.Admin))));

          return results;
        }
    }
}
