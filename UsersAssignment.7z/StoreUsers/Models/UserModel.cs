﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace StoreUsers.Models
{
    public class UserModel
    {
        [Key]
        public int UserId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastName { get; set; }
        [Required]
        public Gender Gender { get; set; }
        [Required]
        public int Age { get; set; }
        [Required]
        public List<Roles> Roles { get; set; }
    }
    public enum Gender
    {
        Men,
        Women,
    }

    public enum Roles
    {
        Manger,
        Employee,
        Admin
    }
}
