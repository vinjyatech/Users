using StoreUsers.Controllers;
using StoreUsers.Models;
using System;
using System.Collections.Generic;
using Xunit;

namespace XUnitTestProject1
{
    public class UnitTest1
    {
        [Fact]
        public void GetWomensTest()
        {
            UserController userController = new UserController();
            List<UserModel> userModels = new List<UserModel>();
            UserModel userModel = new UserModel();
            userModel.FirstName = "Iniya";
            userModel.LastName = "Vinothkumar";
            userModel.Age = 24;
            userModel.Roles.Add(Roles.Admin);
            userModel.UserId = 2020;
            userModels.Add(userModel);
            var result = userController.GetWomens(userModels);
            Assert.Equal(24,userModel.Age);
        }
        [Fact]
        public void GetYoungestManTest()
        {
            UserController userController = new UserController();
            List<UserModel> userModels = new List<UserModel>();
            UserModel userModel = new UserModel();
            userModel.FirstName = "Iniya";
            userModel.LastName = "Vinothkumar";
            userModel.Age = 10;
            userModel.Roles.Add(Roles.Admin);
            userModel.UserId = 2020;
            userModels.Add(userModel);
            userModel.FirstName = "Maha";
            userModel.LastName = "Vinothkumar";
            userModel.Age = 24;
            userModel.Roles.Add(Roles.Admin);
            userModel.UserId = 2020;
            var result = userController.GetYoungestMan(userModels);
            Assert.Equal(10, userModel.Age);
        }
        [Fact]
        public void GetWomenRoleTest()
        {
            UserController userController = new UserController();
            List<UserModel> userModels = new List<UserModel>();
            UserModel userModel = new UserModel();
            userModel.FirstName = "Iniya";
            userModel.LastName = "Vinothkumar";
            userModel.Age = 24;
            userModel.Roles.Add(Roles.Admin);
            userModel.Roles.Add(Roles.Manger);
            userModel.UserId = 2020;
            userModels.Add(userModel);
            var result = userController.GetWomenRole(userModels);
            Assert.Equal(Roles.Admin, userModel.Roles);
        }
    }
}
